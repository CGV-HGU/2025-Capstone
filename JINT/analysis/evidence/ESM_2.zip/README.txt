From Monocular Floor Boundaries to Local Navigation with V-LiDAR
Journal of Intelligent & Robotic Systems | Online Resource 2
Hyunwoo Gu, Gunmin Yoo, Hyunseo Lee, Hyunmo Kang, Minseok Lee, and Sung Soo Hwang
School of Artificial Intelligence, Computer and Electrical Engineering, Handong Global University, Pohang 37554, Republic of Korea
Corresponding author: Sung Soo Hwang (sshwang@handong.edu)

Numerical data for offline CPU timing, recorded scan cadence, paired temporal
filter results, and the recorded navigation diagnostics.

Unzip this archive and run `python3 recompute_numeric_supplement.py` with NumPy
installed. It creates four recomputed_*.csv files beside the script.

cpu_frames.csv contains the retained per-frame processing times in milliseconds.
The first sample from each of the two recordings was excluded before export.
Frame numbers identify rows within their original clip.

scan_messages.csv contains relative nanosecond timestamps. The same origin was
subtracted from both clocks within each recording. Blank source_ns denotes a
zero acquisition stamp. For the November cadence table use the seven nav_* IDs.
Hall test and Hall rerun correspond to nav_test_11_26 and nav_trail_1_26. The two
vlidar_run records support the historical source-stamp comparison in the text.

filter_windows.csv gives the replay windows from recorder start, including the
one-second initialization period. Each NPZ contains paired bypass_m and enabled_m
float arrays with frames as rows and internal scan channels as columns. Bounds
for valid observations are 0.1 to 10 m. acquisition_elapsed_ns contains elapsed
image acquisition times for the moving clips, where frames match recorded scan
source stamps. It is empty for the fixed-scene clips sampled by recorder time.

This archive supports recalculation of the reported scan and timing statistics.
hall_session_2026-09-21.csv gives the 20 historical hall endpoints relative to
nominal goals reconstructed from the first recorded odometry pose. Its entry
times are relative to recording start. The corresponding hall nav_logs CSV
joins goal client and navigator console results to the 20 bag intervals. Its
result duration starts at acceptance. The bridge session CSVs contain client
outcomes and RGB-odometry comparisons. The Fifth Reading Room session CSV
contains client outcomes, odometric goal distances, and recovery events. The
run-20 costmap CSV gives pre/post grid counts and forward-motion timing. The
chair scan CSV gives sample selection, recorder offsets, projected ranges and
nearby grid costs for the two chair views. The corridor progress CSV covers all
logged failures. The event times use goal acceptance; command and grid offsets
use the local-clear time when present and the failure time otherwise. Blank
entries indicate observations outside the stated time windows. Trial
times for the bridge audit and Fifth Reading Room are relative to goal acceptance
unless the column specifies otherwise. These trial tables contain recorded
navigation diagnostics. External field assessments are separate.

hall_goal_paths.csv gives every wheel x and y sample in the active hall goal
interval, with nanoseconds from the logged client acceptance. The excursions
CSV gives peak absolute lateral position, linearly interpolated first forward
crossings of x=4.0 and 4.5 m, and the last active-goal pose. Blank crossings
indicate the station was never reached. Lateral position is relative to the
nominal centerline.

followup_rgb_samples.csv lists the recorder timestamps of the sampled forward
views. followup_rgb_review.csv describes the initial object and last view of
every retained follow-up recording. Operator motives use a field report only
where available. These annotations do not determine clearance or physical arrival.

box_approach_cues.csv includes recorder timestamps and horizontal box annotations
on 640 by 480 RGB frames. Pixel width is right_x_px minus left_x_px. The V-LiDAR
cue is the inverse of median finite range over the inner half of the box width.
Depth models report median relative disparity over a three-row strip. The
recomputation counts within-clip pairs with strictly different widths above the
specified margin and with increasing cue for the larger image. Pairs share
frames. The resulting counts describe these two approaches.

Raw RGB and separate field observations are held by the authors.
