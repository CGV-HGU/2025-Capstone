V-LiDAR: Monocular Virtual Scans for Reactive Obstacle Avoidance in Structured Indoor Environments
Journal of Intelligent & Robotic Systems | Online Resource 2
Hyunwoo Gu, Gunmin Yoo, Hyunseo Lee, Hyunmo Kang, Minseok Lee, and Sung Soo Hwang
School of Artificial Intelligence, Computer and Electrical Engineering, Handong Global University, Pohang 37554, Republic of Korea
Corresponding author: Sung Soo Hwang (sshwang@handong.edu)

Numerical data for offline CPU timing, recorded scan cadence, paired temporal
filter results, and the recorded navigation diagnostics.

Unzip this archive and run `python3 recompute_numeric_supplement.py` with NumPy
installed. It creates three recomputed_*.csv files beside the script.

cpu_frames.csv contains the retained per-frame processing times in milliseconds.
The first sample from each of the two recordings was excluded before export.
Frame numbers identify rows within their original clip.

scan_messages.csv contains relative nanosecond timestamps. The same origin was
subtracted from both clocks within each recording. Blank source_ns denotes a
zero acquisition stamp. For the November cadence table use the seven nav_* IDs.
Hall test and Hall rerun correspond to nav_test_11_26 and nav_trail_1_26. The two
vlidar_run records support the historical source-stamp comparison in the text.

filter_windows.csv gives the replay windows from recorder start, including the
one-second initialization period. Each NPZ contains paired bypass_m and enabled_m
float arrays with frames as rows and internal scan channels as columns. Bounds
for valid observations are 0.1 to 10 m. acquisition_elapsed_ns contains elapsed
image acquisition times for the moving clips, where frames match recorded scan
source stamps. It is empty for the fixed-scene clips sampled by recorder time.

This archive supports recalculation of the reported scan and timing statistics.
hall_session_2026-09-21.csv gives the 20 historical hall endpoints relative to
nominal goals reconstructed from the first recorded odometry pose. Its entry
times are relative to recording start. The bridge session CSVs contain client
outcomes and RGB-odometry comparisons. The Fifth Reading Room session CSV
contains client outcomes, odometric goal distances, and recovery events. Trial
times for the bridge audit and Fifth Reading Room are relative to goal acceptance
unless the column specifies otherwise. These trial tables contain recorded
navigation diagnostics. External field assessments are separate.

Raw RGB, robot control logs, and adjudicated outcomes are separate records.
