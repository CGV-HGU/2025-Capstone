JINT 이전 4조건 원고 백업
2026-11-27 · 로컬 복원본

기준 커밋은 2ee81817d9fe81bd18b8d4645caca6063b1cfc34다.
이 상태에 원고 전환 직전의 로컬 5열람실 20번 코스트맵 분석을
복원하고 두 PDF와 LaTeX ZIP을 다시 빌드했다.

JINT/JINT_first_draft.pdf에서 이전 원고를 열 수 있다.
소스 ZIP을 새 디렉터리에 풀고 latexmk -pdf main.tex를 실행하면
원고를 독립적으로 빌드할 수 있다.
분석 수치와 그림은 Online Resource 1과 2에 함께 들어 있다.
